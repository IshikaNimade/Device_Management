package com.android.adminportal.data.local.MyPref

/**
 * The enum Preference keys.
 */
enum class DataPreferenceKeys(val key: String) {
    USER_SESSION("session"),
}